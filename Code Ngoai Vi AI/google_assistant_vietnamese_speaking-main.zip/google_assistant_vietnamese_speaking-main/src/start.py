# !/usr/bin/python
import pushtotalk
pushtotalk.pushtotalk_main()

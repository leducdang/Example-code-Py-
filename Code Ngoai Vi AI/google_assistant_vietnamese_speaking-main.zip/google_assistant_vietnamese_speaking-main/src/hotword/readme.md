Nơi để các file hotword để đánh thức loa nhận lệnh

# google_assistant_vietnamese_speaking

# Google Assistant hỗ trợ đa ngôn ngữ trong đó có tiếng Việt

#Giới thiệu: Đây là dự án độ lại loa thông minh chạy Google Assistant hỗ trợ đa ngôn ngữ trong đó có tiếng Việt, phần source code do Nguyễn Duy code lại từ Source Gốc của Google

#Quy trình thực hiện

![ĐỘ PHẦN CỨNG](https://github.com/phanmemkhoinghiep/google_assistant_vietnamese_speaking/blob/main/00_hardware_compatibility_list.md) => ![CÀI ĐẶT MÔI TRƯỜNG](https://github.com/phanmemkhoinghiep/google_assistant_vietnamese_speaking/blob/main/02_software_enviroment_installation_guide.md) => ![CÀI ĐẶT GOOGLE PROJECT](https://github.com/phanmemkhoinghiep/google_assistant_vietnamese_speaking/blob/main/03_google_project_configuration_guide.md) => ![ACTIVE GOOGLE ASSISTANT](https://github.com/phanmemkhoinghiep/google_assistant_vietnamese_speaking/blob/main/04_software_install_active_guide.md) => ![CHẠY GOOGLE ASSISTANT](https://github.com/phanmemkhoinghiep/google_assistant_vietnamese_speaking/blob/main/05_running_guide.md) => ![CẬP NHẬT](https://github.com/phanmemkhoinghiep/google_assistant_vietnamese_speaking/blob/main/06_updating_guide.md) => ![CÀI ĐẶT HOTWORD KHÁC](https://github.com/phanmemkhoinghiep/google_assistant_vietnamese_speaking/blob/main/07_hotword_configuration_guide.md)




